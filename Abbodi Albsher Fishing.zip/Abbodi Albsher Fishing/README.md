### Abbodialbsherx-Fishing {2.0}
---
#### Install
* Kali
```bash
sudo apt-get install python3-pip
pip3 install -r requirements.txt
```
to run..
`sudo python3 start.py`

---
* Termux
```bash
pkg install pip3
pip3 install -r requirements.txt
chmod 777 start.py
```
to run..
`python3 start.py`



